import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-auth-lib',
  template: `
    <p>
      auth-lib works!
    </p>
  `,
  styles: [
  ]
})
export class AuthLibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

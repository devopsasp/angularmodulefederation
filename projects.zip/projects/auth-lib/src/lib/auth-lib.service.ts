import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthLibService {
  private userName: string;

  private messageSubject = new Subject<string>();

  // Observable for components to subscribe to
  message$ = this.messageSubject.asObservable();

  // Method to publish messages
  sendMessage(message: string) {
    this.messageSubject.next(message);
  }

  public get user(): string {
    return this.userName;
  }

  constructor() {}

  public login(userName: string, password: string): void {
    // Authentication for **honest** users TM. (c) Manfred Steyer
    this.userName = userName;
  }
  dispatchCustomEvent(data: any) {
    const event = new CustomEvent('myCustomEvent', { detail: data });
    window.dispatchEvent(event);
  }
}

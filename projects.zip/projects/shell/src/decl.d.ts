declare module 'mfe1/Module';
declare module 'mfe2/Module';

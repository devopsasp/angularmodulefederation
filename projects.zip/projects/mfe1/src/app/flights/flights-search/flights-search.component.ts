import { Component } from '@angular/core';
import { AuthLibService } from 'auth-lib';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-flights-search',
  templateUrl: './flights-search.component.html',
  styleUrls: ['./flights-search.component.css'],
})
export class FlightsSearchComponent {
  user = this.service.user;
  private subscription: Subscription;
  receivedMessage: string;
  private eventListener: EventListener;
  eventMessage: string | undefined;
  constructor(private service: AuthLibService) {}

  search(): void {
    alert('Not implemented for this demo!');
  }

  terms(): void {
    alert('Not implemented for this demo!');
  }
  ngOnInit() {
    // Subscribe to messages from the shell
    this.subscription = this.service.message$.subscribe((message) => {
      this.receivedMessage = message;
      console.log('Received message from shell:', message);
    });
    this.eventListener = (event: CustomEvent) => {
      console.log('Received custom event:', event.detail);
      // Handle the event data as needed
      this.eventMessage = event.detail.message;
    };
    window.addEventListener('myCustomEvent', this.eventListener);
  }
  ngOnDestroy() {
    // Unsubscribe to avoid memory leaks
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
